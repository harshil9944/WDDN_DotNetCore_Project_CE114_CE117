$(function() {
    $('#datepicker').datepicker({
        uiLibrary: 'bootstrap4'
    });
});
