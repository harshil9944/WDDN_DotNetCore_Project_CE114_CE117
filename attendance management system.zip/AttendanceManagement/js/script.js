$(document).ready(function(){

    // jQuery methods go here...

    $(".dropdown-trigger").dropdown();

     $('.sidenav').sidenav();
     

 
 });

        